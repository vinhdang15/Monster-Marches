using UnityEngine.UI;

public class BtnLoadStartMenu : BtnBase
{
    protected override void Start() 
    {
        sceneName = "StartMenuScene";
        base.Start();
    }
}