public class TowerData
{
        public string   towerType;
        public int      level;
        public string   SpawnObject;
        public float    spawnRate;
        public float    timeToSpawn;
        public float    rangeDetect;
        public float    rangeRaycast;
        public int      goldRequired; 
        public string   descriptions;
}
