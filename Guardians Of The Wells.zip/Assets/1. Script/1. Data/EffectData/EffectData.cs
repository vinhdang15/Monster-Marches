using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EffectData
{
    public string   effectType;
    public int      effectValue;
    public float    effectDuration;
    public int      effectOccursTime;
    public float    effectRange;
}
