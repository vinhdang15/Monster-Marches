public class BulletData
{
        public string   bulletType;
        public int      damage;
        public float    speed;
        public string   effectTyes;
        public float    dealDamageDelay;
}
