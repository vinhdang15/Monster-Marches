using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EmptyPlotData
{
    public float x;
    public float y;
}
