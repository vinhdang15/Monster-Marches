public class UnitData
{
    public string   unitType;
    public string   unitName;
    public int      maxHP;
    public float    moveSpeed;
    public float    attackSpeed;
    public int      damage;
    public int      gold;
    public string   specialAbility;
}
