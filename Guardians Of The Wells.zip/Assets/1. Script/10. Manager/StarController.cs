using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StarController : MonoBehaviour
{
    private Vector2 oneStar;
    private List<Vector2> twoStar = new List<Vector2>();
    private List<Vector2> threeStar = new List<Vector2>();
    

    public void StarControllerPrepare()
    {
        oneStar = new Vector2(0, -115);
        twoStar = new List<Vector2>()
        {
            new Vector2(-65, 115),
            new Vector2(65, 115)
        };

        threeStar = new List<Vector2>()
        {
            new Vector2(-100, 100),
            new Vector2(0, 150),
            new Vector2(100, 100)
        };
    }
}
